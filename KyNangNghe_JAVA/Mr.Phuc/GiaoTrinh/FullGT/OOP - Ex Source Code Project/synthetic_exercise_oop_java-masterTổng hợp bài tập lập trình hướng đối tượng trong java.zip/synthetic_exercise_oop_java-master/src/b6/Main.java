package b6;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        School school = new School();

        // add Student to school by func add(). for ex: school.add(new Student(// infor);

        school.getStudent20YearOld();

        school.countStudent23YearOldInDN();
    }
}
